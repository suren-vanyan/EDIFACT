﻿using EdiWeave.Core.Model.Edi.Edifact;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace EdiWeave.Edifact.UN.D99B
{
    public class EF_EDIFACT_D99B_IFTMBC_Builder
    {
        public static UNB BuildUNB(JToken model)
        {
            var carrierBookingConfirmation = model.SelectToken("CarrierBookingConfirmation");
            var messageinfos = carrierBookingConfirmation.SelectToken("Messageinfos").First;
            var res = messageinfos.SelectToken("MessageDate").ToString();

            DateTime.TryParseExact(s: res, format: "yyyyMMddHHmm", provider: CultureInfo.InvariantCulture, style: 0, out var dt);

            return new UNB
            {
                SYNTAXIDENTIFIER_1 = new S001
                {
                    // Syntax Identifier
                    SyntaxIdentifier_1 = "UNOC",
                    // Syntax Version Number
                    SyntaxVersionNumber_2 = "1"
                },
                INTERCHANGESENDER_2 = new S002
                {
                    // Interchange sender identification
                    InterchangeSenderIdentification_1 = messageinfos.SelectToken("Sender").ToString(),
                    // Identification code qualifier
                    IdentificationCodeQualifier_2 = "ZZZ",
                },
                INTERCHANGERECIPIENT_3 = new S003
                {
                    // Interchange recipient identification
                    InterchangeRecipientIdentification_1 = messageinfos.SelectToken("Receiver").ToString(),
                    // Identification code qualifier
                    IdentificationCodeQualifier_2 = "ZZZ",
                },
                DATEANDTIMEOFPREPARATION_4 = new S004
                {
                    // Date
                    Date_1 = dt.ToString("yyMMdd"),//"200807",
                    // Time
                    Time_2 = dt.ToString("HHmm")//"0849"
                },
                // Interchange control reference
                // Must be incremented with every interchange
                InterchangeControlReference_5 = "17386636",
            };
        }


        /// <summary>
        /// Booking confirmation
        /// </summary>
        public static TSIFTMBC BuildIFTMBC(string controlNumber, JToken model)
        {
            var result = new TSIFTMBC();

            var carrierBookingConfirmation = model.SelectToken("CarrierBookingConfirmation");

            ////Message header
            result.UNH = new UNH();
            result.UNH.MessageReferenceNumber_01 = controlNumber.PadLeft(14, '0');
            result.UNH.MessageIdentifier_02 = new S009();
            result.UNH.MessageIdentifier_02.MessageType_01 = "IFTMBC";
            result.UNH.MessageIdentifier_02.MessageVersionNumber_02 = "D";
            result.UNH.MessageIdentifier_02.MessageReleaseNumber_03 = "99B";
            result.UNH.MessageIdentifier_02.ControllingAgencyCoded_04 = "UN";


            ////Beginning of a message
            var bookingHeader = carrierBookingConfirmation.SelectToken("BookingHeader")?.First;

            result.BGM = new BGM();
            result.BGM.DOCUMENTMESSAGENAME_01 = new C002();
            result.BGM.DOCUMENTMESSAGENAME_01.Documentnamecode_01 = "770";
            result.BGM.MessageFunctionCode_03 = bookingHeader.SelectToken("BookingStatus")?.ToString();
            result.BGM.ResponseTypeCode_04 = bookingHeader.SelectToken("CarrierResponseType")?.ToString();

            ////Contact information
            var messageContact = carrierBookingConfirmation.SelectToken("MessageContact")?.First;

            result.CTA = new CTA();
            //Confirmed with https://www.truugo.com/edifact/d99b/cl3139/
            result.CTA.ContactFunctionCode_01 = "CW";
            result.CTA.DEPARTMENTOREMPLOYEEDETAILS_02 = new C056();
            result.CTA.DEPARTMENTOREMPLOYEEDETAILS_02.Departmentoremployee_02 = messageContact.SelectToken("ContactName")?.ToString();


            ////COMMUNICATION CONTACT
            result.COM = new List<COM>();

            var com1 = new COM();
            com1.COMMUNICATIONCONTACT_01 = new C076();
            com1.COMMUNICATIONCONTACT_01.CommunicationNumber_01 = messageContact.SelectToken("ContactEmail")?.ToString();
            //Electronic mail
            com1.COMMUNICATIONCONTACT_01.CommunicationChannelQualifier_02 = "EM";
            result.COM.Add(com1);


            ////DATE/TIME/PERIOD

            var messageinfos = carrierBookingConfirmation.SelectToken("Messageinfos")?.First;

            result.DTM = new List<DTM>();
            var dtm1 = new DTM();
            dtm1.DATETIMEPERIOD_01 = new C507();
            dtm1.DATETIMEPERIOD_01.Dateortimeorperiodfunctioncodequalifier_01 = "137";
            dtm1.DATETIMEPERIOD_01.Dateortimeorperiodvalue_02 = messageinfos.SelectToken("MessageDate")?.ToString();
            // TODO
            dtm1.DATETIMEPERIOD_01.Dateortimeorperiodformatcode_03 = "203";
            result.DTM.Add(dtm1);

            //var dtm2 = new DTM();
            //dtm1.DATETIMEPERIOD_01 = new C507();
            //dtm1.DATETIMEPERIOD_01.Dateortimeorperiodfunctioncodequalifier_01 = "137";
            //dtm1.DATETIMEPERIOD_01.Dateortimeorperiodvalue_02 = messageinfos.SelectToken("MessageDate").ToString();
            //// TODO
            //dtm1.DATETIMEPERIOD_01.Dateortimeorperiodformatcode_03 = "203";
            //result.DTM.Add(dtm2);


            ////Transport service requirements
            ////A segment to provide confirmation details of the required transport services.

            var generalInformation = carrierBookingConfirmation.SelectToken("GeneralInformation")?.First;

            result.TSR = new List<TSR>();
            var tsr = new TSR();
            tsr.CONTRACTANDCARRIAGECONDITION_01 = new C536();
            tsr.CONTRACTANDCARRIAGECONDITION_01.Contractandcarriageconditioncode_01 = generalInformation.SelectToken("TransportMove")?.ToString();
            result.TSR.Add(tsr);


            ////FTX, Free text
            var remark = carrierBookingConfirmation.SelectToken("Remarks")?.First.SelectToken("Remark")?.First;

            result.FTX = new List<FTX>();
            var ftx = new FTX();
            //AAI General information - Self explanatory.           
            ftx.Textsubjectcodequalifier_01 = remark.SelectToken("Code")?.ToString();
            ftx.TEXTLITERAL_04 = new C108();
            ftx.TEXTLITERAL_04.Freetext_01 = remark.SelectToken("Text")?.ToString();
            result.FTX.Add(ftx);


            ////LOC
            //TODO Foreach
            var transport = carrierBookingConfirmation.SelectToken("Transports")?.First.SelectToken("Transport")?.First;

            result.LOCLoop = new List<Loop_LOC_IFTMBC>();

            var lOCLoop1 = new Loop_LOC_IFTMBC();
            // LOC, Place/location identification      
            lOCLoop1.LOC = new LOC();
            //TODO
            //87 Place / port of conveyance initial arrival
            lOCLoop1.LOC.Locationfunctioncodequalifier_01 = "87";
            lOCLoop1.LOC.LOCATIONIDENTIFICATION_02 = new C517();
            lOCLoop1.LOC.LOCATIONIDENTIFICATION_02.Locationnamecode_01 = transport.SelectToken("DestinationCode")?.ToString();
            //181  Activity Code identifying activities.
            lOCLoop1.LOC.LOCATIONIDENTIFICATION_02.Codelistidentificationcode_02 = "181";
            //6  UN / ECE(United Nations - Economic Commission for Europe)
            lOCLoop1.LOC.LOCATIONIDENTIFICATION_02.Codelistresponsibleagencycode_03 = "6";

            lOCLoop1.LOC.RELATEDLOCATIONONEIDENTIFICATION_03 = new C519();
            //Specification of the first related place/location by code.
            lOCLoop1.LOC.RELATEDLOCATIONONEIDENTIFICATION_03.Relatedplacelocationoneidentification_01 = "US";
            //162  Country Identification of a country.
            lOCLoop1.LOC.RELATEDLOCATIONONEIDENTIFICATION_03.Codelistidentificationcode_02 = "162";
            //5  ISO (International Organization for Standardization)
            lOCLoop1.LOC.RELATEDLOCATIONONEIDENTIFICATION_03.Codelistresponsibleagencycode_03 = "5";

            lOCLoop1.DTM = new List<DTM>();
            dtm1 = new DTM();
            dtm1.DATETIMEPERIOD_01 = new C507();

            result.LOCLoop.Add(lOCLoop1);


            return result;

        }
    }
}
