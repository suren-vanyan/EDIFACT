﻿using EdiWeave.Core.Annotations.Edi;
using EdiWeave.Core.ErrorCodes;
using EdiWeave.Core.Model.Edi;
using EdiWeave.Core.Model.Edi.ErrorContexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace EdiWeave.Core.Annotations.Validation
{
    /// <summary>
    /// Validation attribute for mandatory items. 
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class RequiredAttribute : ValidationAttribute
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredAttribute"/> class.
        /// </summary>
        public RequiredAttribute()
            : base(1)
        {
        }

        /// <summary>
        /// Detects if an item is mandatory and exists.
        /// </summary>
        /// <param name="instanceContext">The instance context.</param>
        /// <param name="segmentIndex">The segment position.</param>
        /// <param name="inSegmentIndex">The position within the segment.</param>
        /// <param name="inCompositeIndex">The position within the component if any.</param>
        /// <param name="repetitionIndex">The repetition position.</param>
        /// <returns>A list of segment errors if invalid, otherwise nothing.</returns>
        public override List<SegmentErrorContext> Validate(InstanceContext instanceContext, int segmentIndex,
            int inSegmentIndex, int inCompositeIndex, int repetitionIndex)
        {
            var result = new List<SegmentErrorContext>();

            if (instanceContext.Instance != null)
                return result;

            if (instanceContext.IsPropertyOfType<AllAttribute>())
            {
                result.AddRange(ValidateAll(instanceContext, segmentIndex));
                return result;
            }

            if (instanceContext.IsPropertyOfType<GroupAttribute>())
            {
                result.Add(ValidateGroup(instanceContext, segmentIndex));
                return result;
            }

            if (instanceContext.IsPropertyOfType<SegmentAttribute>())
            {
                result.Add(ValidateSegment(instanceContext, segmentIndex));
                return result;
            }

            if (instanceContext.IsPropertyOfType<CompositeAttribute>())
            {
                result.Add(ValidateComposite(instanceContext, segmentIndex, inSegmentIndex));
                return result;
            }

            if (instanceContext.Property.IsString())
            {
                result.Add(ValidateDataElement(instanceContext, segmentIndex, inSegmentIndex, inCompositeIndex));
                return result;
            }

            throw new Exception(string.Format("Property {0} of type {1} is not supported.", instanceContext.Property.Name,
                instanceContext.Property.GetGenericType().Name));
        }

        private List<SegmentErrorContext> ValidateAll(InstanceContext instanceContext, int segmentIndex)
        {
            var result = new List<SegmentErrorContext>();

            var mandatoryItems =
                instanceContext.Property.GetGenericType()
                    .GetProperties()
                    .Where(p => p.GetCustomAttribute<RequiredAttribute>() != null)
                    .Select(s => s.GetGenericType());

            result.AddRange(
                mandatoryItems.Select(
                    item =>
                        new SegmentErrorContext(item.GetCustomAttribute<EdiAttribute>().Id, segmentIndex + 1, item,
                            SegmentErrorCode.RequiredSegmentMissing)));

            return result;
        }

        private SegmentErrorContext ValidateGroup(InstanceContext instanceContext, int segmentIndex)
        {
            return new SegmentErrorContext(instanceContext.GetId(), segmentIndex + 1, instanceContext.GetStandardType(),
                SegmentErrorCode.RequiredSegmentMissing);
        }

        private SegmentErrorContext ValidateSegment(InstanceContext instanceContext, int segmentIndex)
        {
            return new SegmentErrorContext(instanceContext.GetId(), segmentIndex + 1, instanceContext.GetStandardType(),
                SegmentErrorCode.RequiredSegmentMissing);
        }

        private SegmentErrorContext ValidateComposite(InstanceContext instanceContext,
            int segmentIndex, int inSegmentIndex)
        {
            if (instanceContext.Parent == null || !instanceContext.Parent.IsPropertyOfType<SegmentAttribute>())
                throw new Exception(string.Format("Parent of composite {0} must be a segment.",
                    instanceContext.Property.Name));

            var result = new SegmentErrorContext(instanceContext.Parent.GetId(), segmentIndex, instanceContext.Parent.GetStandardType());
            var errorContext = new DataElementErrorContext(instanceContext.GetId(), inSegmentIndex,
                DataElementErrorCode.RequiredDataElementMissing, 0, 0, null);
            result.Add(errorContext);
            
            return result;
        }

        private SegmentErrorContext ValidateDataElement(InstanceContext instanceContext,
            int segmentIndex, int inSegmentIndex, int inCompositeIndex)
        {
            if (instanceContext.Parent == null)
                throw new Exception(string.Format("Parent of data element {0} must be either a segment or a composite.",
                    instanceContext.Property.Name));

            var segmentName = instanceContext.Parent.IsPropertyOfType<SegmentAttribute>()
                ? instanceContext.Parent.GetId()
                : instanceContext.Parent.GetDeclaringTypeId();

            var segmentType = instanceContext.Parent.IsPropertyOfType<SegmentAttribute>()
                ? instanceContext.Parent.GetStandardType()
                : instanceContext.Parent.Property.GetStandardDeclaringType();

            if (string.IsNullOrEmpty(segmentName) && instanceContext.Parent.Instance != null)
            {
                var type = instanceContext.Parent.Instance.GetStandardType();
                var ediAttribute = type.GetCustomAttribute<EdiAttribute>();
                if (ediAttribute == null)
                    throw new Exception(string.Format("Can't find segment name for {0}", GetType().Name));

                segmentName = ediAttribute.Id;
                segmentType = type;
            }

            var dataElementAttr = instanceContext.Property.GetCustomAttribute<DataElementAttribute>();
            var name = dataElementAttr == null ? "" : dataElementAttr.Code;

            var result = new SegmentErrorContext(segmentName, segmentIndex, segmentType);
            var errorContext = new DataElementErrorContext(name, inSegmentIndex,
                DataElementErrorCode.RequiredDataElementMissing, inCompositeIndex, 0, null);
            result.Add(errorContext);

            return result;
        }
    }
}
